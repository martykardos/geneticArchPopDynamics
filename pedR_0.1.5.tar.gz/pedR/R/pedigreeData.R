#' An example pedigree
#'
#' examplePedigree returns a dataset containing simulated pedigree information. The variables are
#' defined below.
#'
#' \itemize{
#'   \item id. Individaul identity
#'   \item mom. The identity of the first parent. Unknown mothers (for all founders) are given as NA.
#'   \item dad. The identity of the second parent. Unknown fathers (for all founders) are given as NA.
#'   \item gen. Generation the individual was born.
#'   \item immVec. Indicates whether the individual is an founder (0 = non-founder; 1 = founder)
#' }
#'
#' @docType data
#' @keywords datasets
#' @name examplePedigree
#' @usage data(examplePedigree)
#' @format A data frame with 1000 rows and 5 variables
#' @author Marty Kardos (martykardos@@gmail.com)
NULL
