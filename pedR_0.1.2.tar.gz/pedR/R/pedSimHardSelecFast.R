#' A function to simulate selection, evolution, and population dyamics in a closed population
#'
#' This function runs a forward-time, genomic simulation of evolution in a closed population. The simulation
#' saves the entire pedigree, genotypes at any number of simulated loci, quantitative trait
#' characteristics (e.g., heritability), allele frequencies at all simulated loci (including quantitative trait loci) throughout the simulation.
#' @param chrNum Number of simulated chromosomes. Must equal the length of chrLengs physLengs (see below). This will be overridden if a map file is provided.
#' @param chrLengs Vector of length chrNum giving the chromosome sizes in centiMorgans. Set to NULL if reading in a map file. This will be overridden if a map file is provided.
#' @param physLengs Vector of length chrNum giving the physical chromosome lengths in Megabases. This will be overridden if a map file is provided.
#' @param map A map file object to be used to assign physical chromosome sizes and the landscape of recombination rates across each chromosome.
#'     Genetic and physical chromsome lengths in the map file will override chrNum, chrLengs, and physLengs above when provided.
#' @param simLociNum The total number of SNPs that will be simulated. We first draw allele frequencies in the source population from a beta distribution with shape parameters
#'     of beta1 an beta2 (see below). We then assign diploid genotypes to the founders and immigrants assuming Hardy-Weinberg proportions and
#'     no linkage disequilibrium in the source population. Will be overriden when genotypes are imported (see genoImport below).
#' @param beta1 First shape parameter for the beta distribution for simulating source population allele frequencies.
#' @param beta2 Second shape parameter for the beta distribution for simulating source population allele frequencies.
#' @param gens Maximum number of generations to simulate. Note that the simulation model is of a random mating population (including self fertilization) with
#'     non-overlapping generations.
#' @param burnin Number of generations to run the simulation before beginning simulation and selection on a phenotype. This gives the user the opportunity to allow
#'     time for linkage disequilibrium to build up in the population before imposing selection.
#' @param lastGenSelec The last generation of selection on the quantitative trait. Must be NULL or an integer >burnin and <= than gens.
#' @param popSize Vector of length(gens) giving the population size each generation.
#' @param genoImport An object giving the genotypes of population founders. See 'help(selecSimGenos)' for details on formatting imported founder genotypes.
#' @param QTLFreqs Vector o length 2 giving the minimum and maximum allele frequencies at QTLs during the first generation of selection (burnin + 1).
#' @param h2 The initial narrow sense heritability of the selected trait.
#' @param numLgQTL Number of large effect QTLs.
#' @param numSmQTL Number of small effect QTLs.
#' @param propMajor Initial fraction of the additive genetic variance due to variation in the large effect QTL(s).
#' @param VP The phenotypic variance in the first generation of phenotype simulation and selection.
#' @param phenStart The desired mean phenotype in the first generation of phenotype simulation and selection.
#' @param phenFit The value of the phenotype with the highest fitness.
#' @param survProbs The probability of survival of an individual with the optimal phenotype value (phenFit) in the absence of density dependence.
#' @param carryCap Carrying capacity for the populations. Additional mortality will be imposed when the population exceeds carryCap.
#' @param popSize Starting population size. Must be a single integer >= 2.
#' @param famSize Mean number of offspring produced by each female (Poisson distribution).
#' @details
#'
#'    Output includes 6 objects:
#'
#'    pedObject is a data frame with one row for each individual and six columns including a unique indiviudal identifier (id); the ids
#'    of the two parents (mom and dad); the generation the individual was born in (gen); whether the individual is an immigrant (0 = locally born,
#'    1 = immigrant), and the value of the simulated quantitative trait (indTraitVal).
#'
#'    genoMat gives the genotypes for each simulated individual. Each row represents a locus. Columns include the chromsome identity (chromID), the map position
#'    on the chromosome in centiMorgans (chromMapPos), and the physical position on the chromosome (chromPhysPos). There are then two columns giving the alleles
#'
#'    quantTraitDat is a data frame with 5 columns saving information on the quantitative genetic parameters throughout the simulation, from generations burnin + 1 to gens.
#'    Columns from left to right are generation; the additive genetic variance for the quantitative trait (VaVec); the total phenotypic variance (VpVec); the narrow sense heritability
#'    of the quantitative trait (h2Vec); and the mean value of the trait among all indiviuals in the population (traitMean).
#'
#'    allFreqMat is a data frame storing the allele frequency at every simulated locus throughout the simulation. The first column is the generation (starting with generation 2).
#'    The remaining columns give the allele frequency at every simulated locus in the genome. The corresponding locations of the loci are given in genoMat.
#'
#'    qtlInfo is a data frame with three columns: the ID of the SNPs that were chosen as QTLs (qtls); expected heterozygosity of each QTL in the first generation of trait simulation (generation burnin + 1);
#'    and the effect size and direction of each QTL.
#'
#'    NVec is a vector saving the population sizes for each generation of the simulation. Note that NVec will be shorter than gens if the population goes extinct (i.e., when there is <= 1 adult individual left)
#'
#' @return
#'
#' @examples
#'
#'  library(pedigreeR)
#' # simulate a population with constant recombination rate across each chromosome
#' pedSimHardSelecFast(chrNum=2,chrLengs=rep(50,2),physLengs=rep(100,2),map=NULL,simLociNum=200,beta1=0.5,
#'                beta2=0.5,burnin=1,gens=40,lastGenSelec = 40,genoImport=NULL,QTLFreqs=c(0.01,0.99),h2=0.6,numLgQTL=1,
#'                numSmQTL=99,propMajor = 0.8,VP=10,phenStart = 100,phenFit = 110,survProbs = 0.8,survProbSlope=0.4/10,carryCap = 300,
#'                popSize = 150,famSize = 4)
#'
#' # plot the frequencies of positively selected alleles through time. Line width is proportional to the allele's pheontypic effect size.
#'
#' plot(c(1,ncol(qtlInfo)-5),c(0,1),type="n",ylab="Allele frequency",xlab="Generation of selection")
#' for(i in 1:nrow(qtlInfo)){
#'   lines(1:(ncol(qtlInfo)-5),as.numeric(qtlInfo[i,6:ncol(qtlInfo)]),lwd=qtlInfo[i,3])
#' }
#'
#' # plot the phenotype values through time
#' rollMeans <- rep(NA,40)
#' plot(c(0,40),c(95,115),type="n",xlab="Generation",ylab="Phenotype size")
#' for(i in 1:40){
#'  genDat <- pedObject[which(pedObject[,4] == i),]
#'  points(rep(i,nrow(genDat)),genDat[,8],col="darkblue",pch=16,cex=0.1)
#'  rollMeans[i] <- mean(genDat[,8])
#' }
#'lines(1:40,rollMeans,lwd=2)
#' @importFrom stats rbeta rexp rnorm rpois runif var lm
#' @importFrom utils read.table
#'
#' @export
#'
pedSimHardSelecFast <- function(chrNum,chrLengs,physLengs,map,simLociNum,beta1,beta2,burnin,gens,lastGenSelec,genoImport,QTLFreqs,h2,numLgQTL,numSmQTL,propMajor,VP,phenStart,phenFit,survProbs,survProbSlope,carryCap,popSize,famSize){
  if(is.null(chrLengs) == FALSE & is.null(physLengs) == FALSE & is.null(chrNum) == FALSE){
    if(3*chrNum != sum(chrNum,length(chrLengs),length(physLengs)))stop("lengths of chrLengs and physLengs must equal chrNum")
  }
  if(simLociNum <= 0)stop("must simulate at least one SNP locus")
  if(beta1 <= 0 | beta2 <= 0)stop("beta1 and beta2 must be positive")
  if(is.null(popSize) == TRUE) stop("must specify vector of population sizes")
  if(length(popSize) != 1)stop("popSize must be a single integer giving the starting size of the population")
  if(sum(popSize < 1) > 0)stop("popSize must be a positive integer)")
  if(lastGenSelec <= burnin | lastGenSelec > gens)stop("lastGenSelec must be > burnin and <= gens")

  ###################################
  # read in the map file if specified
  ###################################
  if(is.null(map) == FALSE){
    mapFile <- map
    chrNum <- length(unique(mapFile[,1]))
    chrLengs <- rep(NA,chrNum)
    physLengs <- rep(NA,chrNum)
    for(i in 1:length(physLengs)){
      physLengs [i] <- max(mapFile[which(mapFile[,1] == i),2])
      chrLengs [i]  <- max(mapFile[which(mapFile[,1] == i),3])
    }

    #### calculate segment recombination rates
    recRates <- NULL
    for(i in 1:chrNum){
      thisChrMap <- mapFile[which(mapFile[,1] == i),]
      theseRates <- rep(NA,nrow(thisChrMap))
      for(j in 1:(length(theseRates)-1)){
        theseRates[j] <- (thisChrMap[j+1,3]-thisChrMap[j,3])/(thisChrMap[j+1,2]-thisChrMap[j,2])
      }
      recRates <- c(recRates,theseRates)
    }
    mapFile <- cbind(mapFile,recRates)
  }

  ########################################
  # import founder genotypes if specified
  ########################################
  if(is.null(genoImport) == FALSE){
    importGenos <- genoImport
    simLociNum <- nrow(importGenos)
    if(chrNum != length(unique(importGenos[,1])))stop("chrNum must equal the number of chromosomes in the imported genotype data")
    if(popSize[1] != (ncol(importGenos)-3)/2)stop("Number of imported genotpes must equal the population size in the first generation (popSize [1])")

    #### check that the simulated chromosomes capture all of the imported loci
    importChroms <- unique(importGenos[,1])
    impPhysLengs <- rep(NA,length(importChroms))
    impGenLengs <- rep(NA,length(importChroms))
    for(i in 1:length(importChroms)){
      impPhysLengs[i] <- max(importGenos[which(importGenos[,1] == importChroms[i]),3])
      impGenLengs[i] <- max(importGenos[which(importGenos[,1] == importChroms[i]),2])
    }
    #if(sum(chrLengs <= impGenLengs) > 0) stop("chrLengs must be greater than the map lengths of the corresponding imported chromosomes")
    if(sum(physLengs <= impPhysLengs) > 0) stop("physLengs must be greater than the physical lengths of the corresponding imported chromosomes")
  }
  if(is.null(genoImport)) {allFreqs <- rbeta(n=simLociNum,shape1=beta1,shape2=beta2)}                     # expected heterozygosity at each locus in the source population... these frequencyes will be used to assign founder genotpyes stochastically, assuming infinite Ne (no linkage disequilibrium) in the source population
  VA <- h2*VP                                                                      # assign the additive genetic variance of the phenotype

  if(is.null(genoImport)){
    snpChrs <- sort(sample(1:chrNum,size=simLociNum,replace=TRUE,prob=physLengs))  # assign SNP chromosomes
    snpPos <- NULL                                                                 # assign SNP positions on chromosomes
    for(i in 1:chrNum){
      theseChrs <- snpChrs[which(snpChrs == i)]
      theseSnpPos <- sort(runif(n=length(theseChrs),min=0,max=physLengs[i]))
      snpPos <- c(snpPos,theseSnpPos)
    }
    snpMat <- cbind(snpChrs,snpPos)                                               # object storing SNP chromosome assignments and positions
  }

  if(is.null(genoImport) == FALSE){         # Assign SNP positions if you have imported founder genotypes
    snpChrs <- genoImport[,1]
    snpPos <- genoImport[,3]
    snpMat <- cbind(snpChrs,snpPos)
  }
  id <- 1:popSize[1]
  mom <- rep(NA,popSize[1])
  dad <- rep(NA,popSize[1])
  gen <- rep(1,length(id))
  pedObject <- cbind(id,mom,dad,gen)    # store the simulated pedigree information

  ################################################################
  # initialize founder and immigrant chromosome segment identities
  ################################################################
  fstJuncList <- list()      # lists of length(chroms), where each element is a list of all simulated individuals storing the genetic mapping locations of junctions
  secJuncList <- list()
  fstChrOrigList <- list()   # lists of length(chroms), where each element will be a list of length nrow(pedObject) to store chrom segment origin
  secChrOrigList <- list()
  immVec <- rep(0,nrow(pedObject))   # indicator variable for immigrants
  imms <- which(is.na(pedObject[,2]) == TRUE)  # identify the founders and immigrants
  immVec[imms] <- 1
  pedObject <- cbind(pedObject,immVec)
  for (i in 1:chrNum){
    fstChrOrigList[[i]] <- list()
    secChrOrigList[[i]] <- list()
    fstJuncList[[i]] <- list()
    secJuncList[[i]] <- list()
  }
  for(i in 1:chrNum){
    foundOrigIter <- 1
    for(j in 1:length(imms)){
      fstChrOrigList[[ i ]][[ imms[j] ]] <- foundOrigIter
      foundOrigIter <- foundOrigIter + 1
      secChrOrigList[[ i ]][[ imms[j] ]] <- foundOrigIter
      foundOrigIter <- foundOrigIter + 1
      fstJuncList[[i]] [[imms[j]]] <- c(0,physLengs[i])
      secJuncList[[i]] [[imms[j]]] <- c(0,physLengs[i])
    }
  }

  ##################################################
  # genotype the founders and immigrants chromosomes
  ##################################################
  #### calculate the minor allele frequencies
  if(is.null(genoImport)){
    mafs <- allFreqs
  }
  foundChrGenos <- matrix(NA,nrow=length(imms)*2,ncol=simLociNum+1)
  print("genotyping founding generation")

  if(is.null(genoImport)){          # simulate the genotypes if you have not imported them
    for (i in 2:ncol(foundChrGenos)){
      theseGenos1 <- rep("A",nrow(foundChrGenos))
      allTrials1 <- runif(nrow(foundChrGenos),min=0,max=1)
      if(sum(allTrials1 > mafs[i-1]) > 0){
        theseGenos1[allTrials1 > mafs[i-1]] <- "T"
      }
      foundChrGenos[,i] <- theseGenos1
    }
  foundChrGenos[,1] <- 1:(2*length(imms))
  }

  if(is.null(genoImport) == FALSE){   # imported genotypes for founders
    fstAlls <- seq(4,ncol(importGenos),2)
    secAlls <- fstAlls + 1
    rowIter <- 1
    for(i in 1:length(imms)){
      foundChrGenos [rowIter,2:ncol(foundChrGenos)] <- as.character(importGenos[,fstAlls[i]])
      rowIter <- rowIter + 1
      foundChrGenos [rowIter,2:ncol(foundChrGenos)] <- as.character(importGenos[,secAlls[i]])
      rowIter <- rowIter + 1
    }
  foundChrGenos[,1] <- 1:(2*length(imms))
  }
  genoMat1 <- matrix(NA,nrow=length(imms),ncol=simLociNum+1)
  genoMat2 <- matrix(NA,nrow=length(imms),ncol=simLociNum+1)
  fstAlls <- seq(1,length(imms)*2,2)
  secAlls <- seq(2,length(imms)*2,2)
  for(i in imms){
    genoMat1[i,] <- foundChrGenos[fstAlls[i],]
    genoMat2[i,] <- foundChrGenos[secAlls[i],]
  }
  genoMat1[1:length(imms),1] <- imms
  genoMat2[1:length(imms),1] <- imms

  #################################################
  # keep track of quantitative trait parameters
  #################################################
  sVec <-  rep(NA,length((burnin+1):gens))
  VaVec <- rep(NA,length((burnin+1):gens))
  VpVec <- rep(NA,length((burnin+1):gens))
  h2Vec <- rep(NA,length((burnin+1):gens))
  allFreqMat <- matrix(NA,nrow=gens,ncol=simLociNum)
  traitMean <- rep(NA,length((burnin+1):gens))
  indTraitVal <- NULL # vector storing the trait value for every simulated individual
  qtlInfo <- NULL  # object storing the locations and effect sizes of the simulated QTLs
  NVec <- nrow(pedObject)

  ######################################
  # simulate 2:gens generations
  ######################################
  i <- 2            # iterate over generations
  extinct <- FALSE  # the population size is > 0 to start
  while(i <= gens & extinct == FALSE){
    lastG1 <- genoMat1[,2:ncol(genoMat1)]
    lastG2 <- genoMat2[,2:ncol(genoMat2)]
    lastGIDs <- pedObject[which(pedObject[,4] == i-1),1]
    aCnts1 <- colSums(lastG1 == "A")
    aCnts2 <- colSums(lastG2 == "A")
    aCnts <- aCnts1 + aCnts2
    aFreqs <- aCnts /(2*nrow(lastG1))
    hetMat <- lastG1 != lastG2
    obsHets <- colSums(hetMat)/nrow(hetMat)
    expHet <- 2*aFreqs*(1-aFreqs)
    Fis <- 1-(obsHets/expHet)
    allFreqMat[i,] <- aFreqs
    if(i < (burnin + 1)){indTraitVal <- c(indTraitVal,rep(NA,nrow(pedObject) - length(indTraitVal)))}
    if(i >= (burnin + 1)){       # if the burnin is over, then calculate allele frequencies so that you can identify QTLs
      expHet <- 2*aFreqs*(1-aFreqs)                                            # expected heterozygosity

      ###################################################################
      # assign the QTL effects (the first generation after burnin period)
      ###################################################################
      if(i == burnin + 1){
        candQtls <- which(aFreqs >= QTLFreqs[1] & aFreqs <= QTLFreqs[2])       # Identify candidate QTL loci based on allele frequency
        qtls <- sort(sample(candQtls,size=numLgQTL+numSmQTL,replace=FALSE))    # randomly select among the candidate QTL loci
        majQTL <- sample(qtls,size=numLgQTL,replace=FALSE)                     # randomly select a major effect locus
        qtlExpHet <- expHet[qtls]                                              # expected heterozygosity at the QTLs
        qtl1Mat <- lastG1[,qtls]              # pull out the QTLs
        qtl2Mat <- lastG2[,qtls]
        numAs <- (qtl1Mat == "A") + (qtl2Mat == "A")   # count the As in each individual at each locus
        locusPropVars <- rep(NA,numLgQTL+numSmQTL)                             # locus-specific proportional genetic variances
        expSamps <- rexp(n = numSmQTL,rate=1)                                  # sample effect sizes of small effect loci from an exponential distribution
        expSizes <- ((1-propMajor)/sum(expSamps))*expSamps                     # proportion of the genetic varianc explained by each non-major locus (exponentially distributed)
        locusPropVars[which(qtls %in% majQTL == FALSE)] <- expSizes
        locusPropVars[which(qtls %in%  majQTL)] <- propMajor/numLgQTL
        locusVars <- locusPropVars * VA
        qtlEffs <- sqrt(locusVars/qtlExpHet)
        qtlInfo <- cbind(qtls,qtlExpHet,qtlEffs)
      }
      qtlExpHet <- expHet[qtls]                                                # expected heterozygosity at the QTLs
      majQTLExpHet <- qtlExpHet[which(qtls %in% majQTL)]                       # expected heterozygosity at the major effect QTL(s)
      qtl1Mat <- lastG1[,qtls]                # pull out the QTLs
      qtl2Mat <- lastG2[,qtls]
      numAs <- (qtl1Mat == "A") + (qtl2Mat == "A")                             # count the As in each individual at each locus
      xMat <- numAs * matrix(rep(qtlEffs,sum(pedObject[,4] == i - 1)),nrow=sum(pedObject[,4] == i - 1),ncol=length(qtlEffs),byrow=TRUE)
      Va <- var(rowSums(xMat))                                         # additive genetic variance in the trait
      Vp <- Va/h2                                                              # total phenotypic variance in the trait
      if(i == burnin + 1){
        Ve <- Vp-Va                                                            # environmental (error) variance in the trait. Keep constant after the first generation of selection
        modIntercept <- phenStart - mean(rowSums(xMat))                        # Intercept of the quantitative genetic model, assigned so that the starting mean
      }                                                                        # mean phenotype will be approximately phenStart
      resids <- rnorm(n=sum(pedObject[,4] == i - 1),mean=0,sd=sqrt(Ve))                       # rediduals (adjust phenotypes for random environmental variation)
      phenVec <- modIntercept + rowSums(xMat) + resids                         # assign phenotypic values for each individual
      indTraitVal <- c(indTraitVal,phenVec)
      VaVec [i - burnin] <- Va                                                 # save the quantitative genetic parameter values
      VpVec [i - burnin] <- var(phenVec)
      h2Vec [i - burnin] <- Va/var(phenVec)
      traitMean [i-burnin] <- mean(phenVec)

      ##############################################
      # selection on the phenotype
      ##############################################
      survProbVec <- rep(NA,length(phenVec))
      for(nb in 1:length(survProbVec)){
        survProbVec [nb]<- survProbs - survProbSlope *abs(phenFit - phenVec[nb])
      }
      if(length(phenVec) > carryCap){
        parToK <- 2*(carryCap/(famSize))   # number of parents needed to produce K offspring on average
        survToK <- parToK/length(phenVec)  # mean survival probability needed to get to K on average next generation
        if(mean(survProbVec) > survToK){   # lower survival probabilities to bring the population down to K
          survProbVec <- survProbVec - (mean(survProbVec) - survToK)
        }
      }
      survTest <- runif(n=length(phenVec),min=0,max=1) <= survProbVec
      removeInds <- which(survTest == 0)

      ##########################
      # check for extinction
      ##########################
      if(sum(survTest == 1) <= 1) {
        extinct <- TRUE
      }
      if(sum(survTest) > 1){ # continue if there are at least two parents remaining
        remainInds <- (1:length(phenVec))[which(1:length(phenVec) %in% removeInds == FALSE)]
        if(is.null(lastGenSelec) == FALSE & i > lastGenSelec){                   # consider all individuals as candidate parents if i is greater than the last generation of selection
          remainInds <- 1:length(phenVec)
        }
        moms <- sample(x=pedObject[which(pedObject[,4] == i - 1)[remainInds],1],size=round(0.5*length(remainInds)),replace=TRUE)   # sample moms with selection
        dads <- rep(NA,length(moms))
        for(z in 1:length(moms)){
          possibleDads <- pedObject[which(pedObject[,4] == i - 1)[remainInds],1][-which(pedObject[which(pedObject[,4] == i - 1)[remainInds],1] == moms[z])]
          if(length(possibleDads) > 1){dads[z] <- sample(x=possibleDads,size=1,replace=FALSE)}
          if(length(possibleDads) == 1) dads[z] <- possibleDads
        }
        sVec [i-burnin] <- mean(phenVec[remainInds]) - mean(phenVec)
      }
    }
    if(i <= burnin){                                  # sample moms and dads without allowing self fertilization
      if(length(which(pedObject[,4] == i - 1)) > carryCap){     # increase mortality in fecessary to bring the population to carrying capacity
        remainInds <- sample(1:length(which(pedObject[,4] == i - 1)),carryCap,replace=FALSE)
      }
      if(length(which(pedObject[,4] == i - 1)) <= carryCap){     # sample parents without decreasing population size if the population is already below arrying capacity
        remainInds <- 1:length(which(pedObject[,4] == i - 1))
      }
      moms <- sample(x=pedObject[which(pedObject[,4] == i - 1),1][remainInds],size=0.5*length(pedObject[which(pedObject[,4] == i - 1),1][remainInds]),replace=TRUE)   # sample moms
      dads <- rep(NA,length(moms))
      for(z in 1:length(moms)){
        possibleDads <- pedObject[which(pedObject[,4] == i - 1)[remainInds],1][-which(pedObject[which(pedObject[,4] == i - 1)[remainInds],1] == moms[z])]
        dads[z] <- sample(x=possibleDads,size=1,replace=FALSE)
      }
    }
    # assign family sizes
    nOffs <- 0 # initialize nOffs at zero
    if(length(moms) > 0){        # assign family sizes if there are any mother-father pairs
      nOffs <- rpois(n=length(moms),lambda = famSize)
    }
    if(length(moms) == 0 | sum(nOffs) <= 1){        # check for family sizes sith size > 0
      extinct <- TRUE
    }

    ###################################################
    # assign IDs for new offspring (if there are any)
    ###################################################
    if(sum(nOffs) > 0){
      theseInds <- (nrow(pedObject)+1):(nrow(pedObject)+ sum(nOffs))  # vector of non-immgrant individuals to assign haplotypes to
      id <-  (max(pedObject[,1])+1):(max(pedObject[,1])+length(theseInds))
      gen <- rep(i, length(id))
      immVec <- rep(0,length(id))
      mom <- NULL
      dad <- NULL
      for(z in 1:length(moms)){
        mom <- c(mom,rep(moms[z],nOffs[z]))
        dad <- c(dad,rep(dads[z],nOffs[z]))
      }
      outDat <- cbind(id,mom,dad,gen,immVec)
      pedObject <- rbind(pedObject,outDat)

      #####################################################
      # Mendelian segregation
      #####################################################
      offGenoMat1 <- matrix(NA,nrow=length(theseInds),ncol= simLociNum + 1)          # store the individual genotypes
      offGenoMat2 <- matrix(NA,nrow=length(theseInds),ncol= simLociNum + 1)
      genoMatColIndex <- 2      # index which is the first row where to add offspring genotypes

      for(j in 1:chrNum){
        chromSnpLocs <- snpMat[which(snpMat[,1] == j),2]

         ######### start with the maternal genome copy
         momRecs <- rpois(n=length(theseInds),lambda=chrLengs[j]/100)
         momRecLocsMat <- matrix(NA,nrow=length(theseInds),ncol=max(momRecs)+1)
         for(z in 1:ncol(momRecLocsMat)){   # draw locations of crossovers for all individuals
           momRecLocsMat[which(momRecs >= z),z] <- runif(n=length(which(momRecs >= z)),min=0,max=physLengs[j])
           if(sum(momRecs == (z-1)) > 0) momRecLocsMat[which(momRecs == (z-1)),z] <- physLengs[j]
         }
         if(sum(momRecs > 1) > 0){          # sort locations of crossovers for all individuals
             moreThanOneRec <- which(momRecs > 1)
             for(b in moreThanOneRec){
               momRecLocsMat[b,1:(momRecs[b]+1)] <- sort(momRecLocsMat[b,])
             }
         }
         momChrPicker <- sample(x=c(1,2),size=length(theseInds),replace=TRUE) # which parental chromosome copy to sample first
         offMomGenos <- matrix(NA,nrow=length(theseInds),ncol=sum(snpMat[,1] == j))    #  initialize offspring genotype matrix

         for(b in 1:(max(momRecs)+1)){        # assign genotypes to offspring
           thisMomGenoMat <- matrix(NA,nrow=length(theseInds),ncol=ncol(offMomGenos))
           if(sum(momChrPicker == 1) > 0)thisMomGenoMat[which(momChrPicker == 1),] <- lastG1[match(pedObject[theseInds,2],lastGIDs)[which(momChrPicker == 1)],which(snpMat[,1] == j)]
           if(sum(momChrPicker == 2) > 0)thisMomGenoMat[which(momChrPicker == 2),] <- lastG2[match(pedObject[theseInds,2],lastGIDs)[which(momChrPicker == 2)],which(snpMat[,1] == j)]
           if(b == 1){
             for(p in 1:ncol(offMomGenos)){
               if(sum(momRecLocsMat[,b] >= chromSnpLocs[p],na.rm=TRUE) > 0) offMomGenos[which(momRecLocsMat[,b] >= chromSnpLocs[p]),p] <- thisMomGenoMat[which(momRecLocsMat[,b] >= chromSnpLocs[p]),p]
             }
           }
           if(b > 1){
             for(p in 1:ncol(offMomGenos)){
               if(sum(momRecLocsMat[,b] >= chromSnpLocs[p] & chromSnpLocs[p] > momRecLocsMat[,b-1],na.rm=TRUE) > 0) offMomGenos[which(momRecLocsMat[,b] >= chromSnpLocs[p] & chromSnpLocs[p] > momRecLocsMat[,b-1]),p] <- thisMomGenoMat[which(momRecLocsMat[,b] >= chromSnpLocs[p] & chromSnpLocs[p] > momRecLocsMat[,b-1]),p]
             }
           }
           #### iterate the chrPicker
           newChrPicker <- rep(1,length(momChrPicker))
           if(sum(momChrPicker == 1) > 0) newChrPicker[which(momChrPicker == 1)] <- 2
           momChrPicker <- newChrPicker
         }

         offGenoMat1[,genoMatColIndex:(genoMatColIndex + ncol(offMomGenos) - 1)] <- offMomGenos

         ######### now the paternal genome copy


         dadRecs <- rpois(n=length(theseInds),lambda=chrLengs[j]/100)
         dadRecLocsMat <- matrix(NA,nrow=length(theseInds),ncol=max(dadRecs)+1)
         for(z in 1:ncol(dadRecLocsMat)){   # draw locations of crossovers for all individuals
           dadRecLocsMat[which(dadRecs >= z),z] <- runif(n=length(which(dadRecs >= z)),min=0,max=physLengs[j])
           if(sum(dadRecs == (z-1)) > 0) dadRecLocsMat[which(dadRecs == (z-1)),z] <- physLengs[j]
         }
         if(sum(dadRecs > 1) > 0){          # sort locations of crossovers for all individuals
           moreThanOneRec <- which(dadRecs > 1)
           for(b in moreThanOneRec){
             dadRecLocsMat[b,1:(dadRecs[b]+1)] <- sort(dadRecLocsMat[b,])
           }
         }
         dadChrPicker <- sample(x=c(1,2),size=length(theseInds),replace=TRUE) # which parental chromosome copy to sample first
         offDadGenos <- matrix(NA,nrow=length(theseInds),ncol=sum(snpMat[,1] == j))    #  initialize offspring genotype matrix

         for(b in 1:(max(dadRecs)+1)){
           thisDadGenoMat <- matrix(NA,nrow=length(theseInds),ncol=ncol(offDadGenos))
           if(sum(dadChrPicker == 1) > 0)thisDadGenoMat[which(dadChrPicker == 1),] <- lastG1[match(pedObject[theseInds,3],lastGIDs)[which(dadChrPicker == 1)],which(snpMat[,1] == j)]
           if(sum(dadChrPicker == 2) > 0)thisDadGenoMat[which(dadChrPicker == 2),] <- lastG2[match(pedObject[theseInds,3],lastGIDs)[which(dadChrPicker == 2)],which(snpMat[,1] == j)]
           if(b == 1){
             for(p in 1:ncol(offDadGenos)){
               if(sum(dadRecLocsMat[,b] >= chromSnpLocs[p],na.rm=TRUE) > 0) offDadGenos[which(dadRecLocsMat[,b] >= chromSnpLocs[p]),p] <- thisDadGenoMat[which(dadRecLocsMat[,b] >= chromSnpLocs[p]),p]
             }
           }
           if(b > 1){
             for(p in 1:ncol(offDadGenos)){
               if(sum(dadRecLocsMat[,b] >= chromSnpLocs[p] & chromSnpLocs[p] > dadRecLocsMat[,b-1],na.rm=TRUE) > 0) offDadGenos[which(dadRecLocsMat[,b] >= chromSnpLocs[p] & chromSnpLocs[p] > dadRecLocsMat[,b-1]),p] <- thisDadGenoMat[which(dadRecLocsMat[,b] >= chromSnpLocs[p] & chromSnpLocs[p] > dadRecLocsMat[,b-1]),p]
             }
           }
           #### iterate the chrPicker
           newChrPicker <- rep(1,length(dadChrPicker))
           if(sum(dadChrPicker == 1) > 0) newChrPicker[which(dadChrPicker == 1)] <- 2
           dadChrPicker <- newChrPicker
         }
         offGenoMat2[,genoMatColIndex:(genoMatColIndex + ncol(offDadGenos) - 1)] <- offDadGenos
         genoMatColIndex <- genoMatColIndex + ncol(offDadGenos)    # iterate the column index for new genotypes
      }
      offGenoMat1[,1] <- id
      offGenoMat2[,1] <- id
      genoMat1 <- offGenoMat1
      genoMat2<- offGenoMat2
    } # if statement checking for > 0 offspring in generation i
    print(paste("done with generation ",i,sep=""))
    if(extinct == TRUE){print(paste("population extinct at generation ",i,sep=""))}
    i <- i + 1
  }
  if(length(indTraitVal) < nrow(pedObject)) {indTraitVal <- c(indTraitVal,rep(NA,nrow(pedObject) - length(indTraitVal)))}
  genoMat1 <- genoMat1[which(is.na(genoMat1[,1]) == FALSE),]
  genoMat2 <- genoMat2[which(is.na(genoMat2[,1]) == FALSE),]

  ###########################################
  # calculate the SNP mapping positions
  ###########################################
  chromPhysPos <- NULL
  chromMapPos <- NULL
  for (k in 1:chrNum){
    thesePos  <- snpMat [which(snpMat[,1] == k),2]   # positions of the loci on this chromosome
    chromPhysPos <- c(chromPhysPos,thesePos)
    #### calculate the genetic mapping positions of loci on this chromosome
    if(is.null(map) == FALSE){
      thisChrMap <- mapFile[which(mapFile[,1] == k),]
      thisMapPos <- rep(NA,length(thesePos))
      prevRows <- rep(NA,length(thesePos))
      for(n in 1:length(thisMapPos)){
        prevRows [n] <- which(thisChrMap[,2] < thesePos[n])[length(which(thisChrMap[,2] < thesePos[n]))]
      }
      thisMapPos <- thisChrMap[prevRows,3] + thisChrMap[prevRows,4]* (thesePos-thisChrMap[prevRows,2])
    }
    if(is.null(map) == TRUE){thisMapPos <- (thesePos/physLengs[k]) * chrLengs[k]}
    chromMapPos <- c(chromMapPos,thisMapPos)
  }

  allFreqMat <- cbind(1:gens,allFreqMat)
  colnames(allFreqMat) <- c("gens",paste("l_",(1:simLociNum),sep=""))

  #### add allele frequencies and SNP positions to qtlInfo
  qtlChrs <- snpMat[qtlInfo[,1],1]
  qtlPhysPos <- snpMat[qtlInfo[,1],2]


  qtlFreqs <- NULL
  for(j in 1:nrow(qtlInfo)){
    qtlFreqs <- rbind(qtlFreqs,allFreqMat[,qtlInfo[j,1]+1])
  }
  qtlInfo <- cbind(qtlInfo,qtlChrs,qtlPhysPos,qtlFreqs[,(burnin+1):(ncol(qtlFreqs))])

  colnames(qtlInfo)[6:ncol(qtlInfo)] <- paste("gen",(burnin+1):(ncol(qtlFreqs)),sep="")

  #### make a vector of yearly population sizes
  outGens <- unique(pedObject[,4])
  NVec <- rep(NA,length(outGens))
  for( i in 1:length(outGens)){
    NVec [i] <- sum(pedObject[,4] == i)
  }

  #### trim NAs from output files
  allFreqMat <- allFreqMat[which(is.na(allFreqMat[,2]) == FALSE),]
  qtlInfo <- qtlInfo[,which(is.na(qtlInfo[1,]) == FALSE)]

  #### outputs
  NVec <<- NVec
  pedObject <<- cbind(pedObject,indTraitVal)
  quantTraitDat <<- cbind((burnin+1):gens,VaVec,VpVec,h2Vec,traitMean,sVec) # store information on the location and effect size and direction of each QTL
  allFreqMat <<- allFreqMat[2:nrow(allFreqMat),]
  qtlInfo <<- qtlInfo
  print("**********simulation done**********")
}
