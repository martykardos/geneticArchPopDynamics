#' An example input genotypes for pedigree founders and immigrants in the examplePedigree data set. This dataset is intended for
#' as an example for the simPedSelec function.
#'
#' selecSimGenos returns an example dataset containing imported genotypes for 100 pedigree founders. Loci are represented in rows.
#' Individual genotypes are represented in columns 4 and upward (two columns for each individual). Mapping information is provided in the first three
#' columns. Custom imported genotypes must contain chromosome, mapping, and physical locations of each locus. The maximum physical and genetic positions of loci
#' in imported genotype files must be smaller than the corresponding lengths of each simulated chromsome (see chrLeng and physLengs).
#'
#' \itemize{
#'   \item chrID. Chromosome identity.
#'   \item chrMapPos. Genetic mapping postion of the locus (in centiMorgans) on the chromosome.
#'   \item chrPhysPos. The physical position of the locus (in Megabases) on th chromosome.
#'   \item The remaining variables, given in the format X1a, X1b,..... XNa, XNb give the phased genotypes at the two locus copies (a and b)
#'        for each individual
#' }
#'
#' @docType data
#' @keywords datasets
#' @name selecSimGenos
#' @usage data(selecSimGenos)
#' @format A data frame with 5000 rows and 203 variables
#' @author Marty Kardos (martykardos@@gmail.com)
NULL
