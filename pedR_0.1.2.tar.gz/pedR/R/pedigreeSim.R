#' A function to simulate evolution in a pedigree
#'
#' This function runs a forward-time genomic simulation of evolution in a pedigreed population.
#'     The pedigree can either be imported or simulated under a random mating.
#' @param chrNum Number of simulated chromosomes
#' @param chrLengs Vector of length chrNum giving the chromosome sizes in centiMorgans
#' @param physLengs Vector of length chrNum giving the physical chromosome lengths in Megabases
#' @param map A map file to be used to assign physical chromosome sizes and the landscape of recombination rates across each chromosome.
#'     Genetic and physical chromsome lengths in the map file will override chrNum, chrLengs, and physLengs above when provided.
#' @param simLociNum The function will simulate genotypes in the founders when simLociNum is specified. simLociNum gives the total number
#'     of SNPs that will be simulated. We first draw allele frequencies in the source population from a beta distribution with shape parameters
#'     of beta1 an beta2 (see below). We then assign diploid genotypes to the founders and immigrants assuming Hardy-Weinberg proportions and
#'     no linkage disequilibrium in the source population. Leave blank or assign as NULL if importing genotypes.
#' @param locusLocs Designates the physical positions of SNPs on chromosomes. If is not set to NULL, then simLociNum must be divisible by chrNum.
#' @param beta1 First shape parameter for the beta distribution for simulating source population allele frequencies.
#' @param beta2 Second shape parameter for the beta distribution for simulating source population allele frequencies.
#' @param gens Number of generations to simulate the population. Note that the simulation model is of a random mating population (including self fertilization) with
#'     non-overlapping generations.
#' @param popSize Vector of length(gens) giving the population size each generation.
#' @param immRate Constant immigration rate into the population. The model assumes a continent-island model of migration. Immigrants and founders
#'     all arise from the same infinitely large source population.
#' @param pedImport An pedigree object (space delimited) with columns id(numeric), mom(numeric identifier),
#'     dad(numeric identifier), generation (numeric), immigrant status (1 for immigrants and founders; 0 otherwise)
#' @param genoImport A space-delimited file where the columns are chromosome number, SNP physical position, SNP genetic position, and
#'     subsequent columns giving the phased genotypes off founders and immigants (two columns per individual [one for each allele])
#' @examples
#'
#' # Simulation a random mating population
#'   pedSim(chrNum=10,chrLengs=rep(50,10),physLengs=rep(100,10),map = NULL,simLociNum=100,locusLocs=NULL,beta1=0.5,beta2=0.5,gens=20,popSize=rep(100,20),immRate=0.01,pedImport=NULL,genoImport=NULL)
#'
pedigreeSim <- function(chrNum,chrLengs,physLengs,map,simLociNum,locusLocs,beta1,beta2,gens,popSize,immRate,pedImport,genoImport){
  if( 3*chrNum != sum(chrNum,length(chrLengs),length(physLengs)))stop("lengths of chrLengs and physLengs must equal chrNum")
  if(chrNum <= 0)stop("must simulate at least one chromosome")
  if(simLociNum <= 0)stop("must simulate at least one SNP locus")
  if(beta1 <= 0 | beta2 <= 0)stop("beta1 and beta2 must be positive")
  if(is.null(popSize) == TRUE)stop("must specify vector of population sizes")
  if(length(popSize) != gens)stop("popSize must be a numeric vector of length gens")
  if(is.numeric(immRate) == FALSE | immRate < 0 | immRate > 1)stop("immRate must be numeric and between zero and one")
  if(is.null(pedImport) == FALSE){pedObject <- pedImport}  # import the pedigree
  if(is.null(pedImport) == FALSE){gens <- max(pedObject[,4])} # assign gens to number of generations in the imported pedigree
  if(is.null(genoImport) == FALSE) {
    importGenos <- genoImport
    simLociNum <- nrow(importGenos)
  }
  if(is.null(pedImport) == FALSE){
    popSize <- rep(NA,gens)
    for(i in 1:gens){
      popSize[i] <- sum(pedObject[,4] == i)
    }
  }
  if(sum(popSize < 1) > 0 | length(popSize) != gens)stop("popSize must be a numeric vector (all positive integers) of length gens")

  ###################################
  # read in the map file if specified
  ###################################
  if(is.null(map) == FALSE){
    mapFile <- map
    chrNum <- length(unique(mapFile[,1]))
    chrLengs <- rep(NA,chrNum)
    physLengs <- rep(NA,chrNum)
    for(i in 1:length(physLengs)){
      physLengs [i] <- max(mapFile[which(mapFile[,1] == i),2])
      chrLengs [i] <- max(mapFile[which(mapFile[,1] == i),3])
    }

    ##########################################
    # calculate segment recombination rates
    ##########################################
    recRates <- NULL
    for(i in 1:chrNum){
      thisChrMap <- mapFile[which(mapFile[,1] == i),]
      theseRates <- rep(NA,nrow(thisChrMap))
      for(j in 1:(length(theseRates)-1)){
        theseRates[j] <- (thisChrMap[j+1,3]-thisChrMap[j,3])/(thisChrMap[j+1,2]-thisChrMap[j,2])
      }
      recRates <- c(recRates,theseRates)
    }
    mapFile <- cbind(mapFile,recRates)
  }

  ########################################################################################
  # assign physical locus positions in the genome if you have imported them
  ########################################################################################
  if(is.null(genoImport)){
    snpChrs <-NULL
    for(i in 1:chrNum){
      snpChrs <- c(snpChrs,rep(i,simLociNum/chrNum))
    }
    snpPos <- NULL                                                                 # assign SNP positions on chromosomes
    for(i in 1:chrNum){
      theseChrs <- snpChrs[which(snpChrs == i)]
      if(is.null(locusLocs)){
        theseSnpPos <- sort(runif(n=length(theseChrs),min=0,max=physLengs[i]))
      }
      if(is.null(locusLocs) == FALSE){
        theseSnpPos <- sort(locusLocs)
      }
      snpPos <- c(snpPos,theseSnpPos)
    }
    snpMat <- cbind(snpChrs,snpPos)                                               # object storing SNP chromosome assignments and positions
  }

  ##################################################################
  # assign locus positions when you have imported founder genotypes
  ##################################################################
  if(is.null(genoImport) == FALSE){
    snpChrs <- genoImport[,1]
    snpPos <- genoImport[,2]
    chrNum <- as.numeric(max(genoImport[,1]))
    snpMat <- cbind(snpChrs,snpPos)
  }

  #######################
  # simulate the pedigree
  #######################
  if(is.null(pedImport) == TRUE){
    pedObject <- NULL
    for (i in 1:gens){
      id <- NULL
      mom <- NULL
      dad <- NULL
      if(i ==1){
        id <- 1:popSize[1]
        mom <- rep(NA,popSize[i])
        dad <- rep(NA,popSize[i])
      }
      if(i >1){
        id <- (max(pedObject$id)+1):(max(pedObject$id)+popSize[i])
        mom <- sample(x=pedObject$id[which(pedObject$gen == i - 1)],size=popSize[i],replace=TRUE)
        dad <- sample(x=pedObject$id[which(pedObject$gen == i - 1)],size=popSize[i],replace=TRUE)
      }
      immStat <- rep(NA,popSize[i]) # test for immigrants (these will have genotypes assigned from source populations allele frequencies)
      for(j in 1:popSize[i]){
        immStat [j]<- runif(1,0,1) < immRate
      }
      if(sum(immStat)>0){
        mom[which(immStat > 0)] <- NA
        dad[which(immStat > 0)] <- NA
      }
      gen <- rep(i,popSize[i])
      outDat <- NULL
      outDat <- cbind(id,mom,dad,gen)
      pedObject <- as.data.frame(rbind(pedObject, outDat))    # store the simulated pedigree information
    }
  }

  ################################################################
  # initialize founder and immigrant chromosome segment identities
  ################################################################
  fstJuncList <- list()  # lists of length(chroms), where each element is a list of all simulated individuals storing the genetic mapping locations of junctions
  secJuncList <- list()
  fstChrOrigList <- list()   # lists of length(chroms), where each element will be a list of length nrow(pedObject) to store chrom segment origin
  secChrOrigList <- list()
  immVec <- rep(0,nrow(pedObject))   # indicator variable for immigrants
  imms <- which(is.na(pedObject[,2]) == TRUE)  # identify the founders and immigrants
  immVec[imms] <- 1
  pedObject <- cbind(pedObject,immVec)
  for (i in 1:chrNum){
    fstChrOrigList[[i]] <- list()
    secChrOrigList[[i]] <- list()
    fstJuncList[[i]] <- list()
    secJuncList[[i]] <- list()
  }
  for(i in 1:chrNum){
    foundOrigIter <- 1
    for(j in 1:length(imms)){
      fstChrOrigList[[ i ]][[ imms[j] ]] <- foundOrigIter
      foundOrigIter <- foundOrigIter + 1
      secChrOrigList[[ i ]][[ imms[j] ]] <- foundOrigIter
      foundOrigIter <- foundOrigIter + 1
      fstJuncList[[i]] [[imms[j]]] <- c(0,chrLengs[i])
      secJuncList[[i]] [[imms[j]]] <- c(0,chrLengs[i])
    }
  }

  ##############################
  #Simulate generations 2:gens
  ##############################
  for (i in 2:gens){
    theseInds <- pedObject[which(pedObject[,5] == 0 & pedObject[,4] == i),1]   # vector of non-immgrant individuals to assign haplotypes to
    for(j in 1:length(theseInds)){
      thisMom <- pedObject[which(pedObject[,1] == theseInds[j]),2]
      thisDad <- pedObject[which(pedObject[,1] == theseInds[j]),3]
      chromPickerVec <- rep(c(1,2),500)  # vector you will use to iterate between parental chromosome copies with recombination events during meiosis
      for (k in 1:chrNum){    # meiosis in the mom and dad
        outMomJuncs <- NULL # the junction locations in the offspring that will come from the mom
        outMomOrig <- NULL # the haplotype origins in the offspring that will come from the mom
        momChromOrig1 <- fstChrOrigList[[k]][[thisMom]] # haplotype origins for the mom's first chromosome copy
        momChromOrig2 <- secChrOrigList[[k]][[thisMom]] # haplotype origins for the mom's second chromosome copy
        momChromJunc1 <- fstJuncList[[k]][[thisMom]] # chromosome junctions for the mom's first chromosome copy
        momChromJunc2 <- secJuncList[[k]][[thisMom]] # chromosome junctions for the mom's second chromosome copy
        outDadJuncs <- NULL # the junction locations in the offspring that will come from the dad
        outDadOrig <- NULL # the haplotype origins in the offspring that will come from the dad
        dadChromOrig1 <- fstChrOrigList[[k]][[thisDad]] # haplotype origins for the dad's first chromosome copy
        dadChromOrig2 <- secChrOrigList[[k]][[thisDad]] # haplotype origins for the dad's second chromosome copy
        dadChromJunc1 <- fstJuncList[[k]][[thisDad]] # chromosome junctions for the dad's first chromosome copy
        dadChromJunc2 <- secJuncList[[k]][[thisDad]] # chromosome junctions for the dad's second chromosome copy
        momRecs <- rpois(n=1,lambda=chrLengs[k]/100)  # number of recombinations during meiosis in the mom
        dadRecs <- rpois(n=1,lambda=chrLengs[k]/100)  # number of recombinations during meiosis in the dad
        recLocsMom <- NULL # locations of recombination events during meiosis in each of the parents
        recLocsDad <- NULL

        # make the offspring maternal chromosome copy if there are >=1 crossovers in the maternal meiosis
        momJuncList <- list()               # list of length two carrying the maternal chromsome junction locations
        momJuncList[[1]] <- momChromJunc1
        momJuncList[[2]] <- momChromJunc2
        momOrigList <- list()               # list of length two carrying the maternal chromsome haplotype origins
        momOrigList [[1]] <- momChromOrig1
        momOrigList [[2]] <- momChromOrig2
        momChrIter <- chromPickerVec[sample(x=c(1,2),size=1,replace=FALSE):length(chromPickerVec)]   # which chromosome do we sample before the first crossover?
        if(momRecs > 0){
          outMomJuncs <- 0
          recLocsMom <- sort(runif(n=momRecs,min=0,max=chrLengs[k]))  # locations of recombination events during meiosis in the mom
          for(l in 1:(momRecs)){     # populate the offspring junction and haplotype origins vector
            inJuncs <- outMomJuncs
            outMomJuncs <- c(outMomJuncs,momJuncList[[ momChrIter[l] ]][which(momJuncList[[ momChrIter[l] ]] > max(outMomJuncs) & momJuncList[[ momChrIter[l] ]] < recLocsMom[l])],recLocsMom[l])
            outMomOrig <- c(outMomOrig,momOrigList[[ momChrIter[l] ]][  (which(momJuncList[[ momChrIter[l] ]] >= max(inJuncs))[1]-1) : which(momJuncList[[ momChrIter[l] ]] < recLocsMom[l])[length(which(momJuncList[[ momChrIter[l] ]] < recLocsMom[l]))]])
          }
          inJuncs <- outMomJuncs
          outMomJuncs <- c(outMomJuncs,momJuncList[[ momChrIter[l+1] ]][which(momJuncList[[ momChrIter[l+1] ]] > max(outMomJuncs))])   # finish the offspring junction location and haplotype orgins vector
          outMomOrig <- c(outMomOrig,momOrigList[[ momChrIter[l+1] ]]  [(which(momJuncList[[ momChrIter[l+1] ]] >= max(inJuncs))[1]-1):length(momOrigList[[ momChrIter[l+1] ]])])
        }
        # make the offspring maternal chromosome copy if there are no crossovers in the maternal meiosis
        if(momRecs == 0){
          outMomJuncs <- c(outMomJuncs,momJuncList[[ momChrIter[1] ]]) # finish the offspring junction location and haplotype orgins vector
          outMomOrig <- c(outMomOrig,momOrigList[[ momChrIter[1] ]])
        }

        # make the offspring paternal chromosome copy if there are >=1 crossovers in the paternal meiosis
        dadJuncList <- list()               # list of length two carrying the paternal chromsome junction locations
        dadJuncList[[1]] <- dadChromJunc1
        dadJuncList[[2]] <- dadChromJunc2
        dadOrigList <- list()               # list of length two carrying the paternal chromsome haplotype origins
        dadOrigList [[1]] <- dadChromOrig1
        dadOrigList [[2]] <- dadChromOrig2
        dadChrIter <- chromPickerVec[sample(x=c(1,2),size=1,replace=FALSE):length(chromPickerVec)]   # which chromosome do we sample before the first crossover?
        if(dadRecs > 0){
          outDadJuncs <- 0
          recLocsDad <- sort(runif(n=dadRecs,min=0,max=chrLengs[k]))  # locations of recombination events during meiosis in the dad
          for(l in 1:(dadRecs)){     # populate the offspring junction and haplotype origins vector
            inJuncs <- outDadJuncs
            outDadJuncs <- c(outDadJuncs,dadJuncList[[ dadChrIter[l] ]][which(dadJuncList[[ dadChrIter[l] ]] > max(outDadJuncs) & dadJuncList[[ dadChrIter[l] ]] < recLocsDad[l])],recLocsDad[l])
            outDadOrig <- c(outDadOrig,dadOrigList[[ dadChrIter[l] ]][  (which(dadJuncList[[ dadChrIter[l] ]] >= max(inJuncs))[1]-1) : which(dadJuncList[[ dadChrIter[l] ]] < recLocsDad[l])[length(which(dadJuncList[[ dadChrIter[l] ]] < recLocsDad[l]))]])
          }
          inJuncs <- outDadJuncs
          outDadJuncs <- c(outDadJuncs,dadJuncList[[ dadChrIter[l+1] ]][which(dadJuncList[[ dadChrIter[l+1] ]] > max(outDadJuncs))])   # finish the offspring junction location and haplotype orgins vector
          outDadOrig <- c(outDadOrig,dadOrigList[[ dadChrIter[l+1] ]]  [(which(dadJuncList[[ dadChrIter[l+1] ]] >= max(inJuncs))[1]-1):length(dadOrigList[[ dadChrIter[l+1] ]])])
        }
        # make the offspring paternal chromosome copy if there are no crossovers in the paternal meiosis
        if(dadRecs == 0){
          outDadJuncs <- c(outDadJuncs,dadJuncList[[ dadChrIter[1] ]]) # finish the offspring junction location and haplotype orgins vector
          outDadOrig <- c(outDadOrig,dadOrigList[[ dadChrIter[1] ]])
        }
        fstJuncList[[k]][[theseInds[j]]] <- outMomJuncs           # save the maternal and paternal chromosome information
        secJuncList[[k]][[theseInds[j]]] <- outDadJuncs
        fstChrOrigList[[k]][[theseInds[j]]]<- outMomOrig
        secChrOrigList[[k]][[theseInds[j]]] <- outDadOrig
      }
    }
    print(paste("done with generation ",i,sep=""))
  }

  #################################################################################
  # calculate the minor allele frequencies if immigrant genotypes are not imported
  #################################################################################
  if(is.null(genoImport) == TRUE){
    allFreqs <- rbeta(n=simLociNum,shape1=beta1,shape2=beta2)                     # expected heterozygosity at each locus in the source population... these frequencyes will be used to assign founder genotpyes stochastically, assuming infinite Ne (no linkage disequilibrium) in the source population
    mafs <- allFreqs
  }

  #############################################
  # give the founders and immigrants genotypes
  #############################################
  print("Genotyping founders and immigrants")
  immGenoMat1 <- NULL  # matrix to store the immigrant genotypes; A will be the major allele at each locus in the source population
  immGenoMat2 <- NULL  # matrix to store the immigrant genotypes; A will be the major allele at each locus in the source population
  if(is.null(genoImport)){          # simulate the genotypes if you have not imported them
    for (i in 1:(length(imms))){
      thisImmGeno1 <- rep("A",nrow(snpMat))
      thisImmGeno2 <- rep("A",nrow(snpMat))
      allTrials1 <- runif(nrow(snpMat),min=0,max=1)
      allTrials2 <- runif(nrow(snpMat),min=0,max=1)
      thisImmGeno1[allTrials1 > mafs] <- "T"
      thisImmGeno2[allTrials2 > mafs] <- "T"
      immGenoMat1 <- rbind(immGenoMat1,thisImmGeno1)
      immGenoMat2 <- rbind(immGenoMat2,thisImmGeno2)
    }
    immGenoMat1 <- cbind(unlist(fstChrOrigList[[ 1 ]][ imms ]),immGenoMat1)
    immGenoMat2 <- cbind(unlist(secChrOrigList[[ 1 ]][ imms ]),immGenoMat2)
    immGenoMat <- rbind(immGenoMat1,immGenoMat2)                            # all immigrant genotypes
  }
  if(is.null(genoImport) == FALSE){   # imported genotypes for founders and immigrants
    fstAlls <- seq(4,ncol(importGenos),2)
    secAlls <- fstAlls + 1
    immigrantIndex <- which(pedObject[,5] == 1)
    immGenoMat1 <- t(  importGenos[,fstAlls] )
    immGenoMat2 <- t(  importGenos[,secAlls] )
    immGenoMat1 <- cbind(unlist(fstChrOrigList[[ 1 ]][ imms ]),immGenoMat1)
    immGenoMat2 <- cbind(unlist(secChrOrigList[[ 1 ]][ imms ]),immGenoMat2)
    immGenoMat <- rbind(immGenoMat1,immGenoMat2)
  }

  ###########################################
  # calculate the SNP mapping positions
  ###########################################
    chromMapPos <- NULL
    for (k in 1:chrNum){
      thesePos <- snpMat[which(snpMat[,1] == k),2]
      #### calculate the genetic mapping positions of loci on this chromosome
      if(is.null(map) == FALSE){
        thisChrMap <- mapFile[which(mapFile[,1] == k),]
        thisMapPos <- rep(NA,length(thesePos))
        prevRows <- rep(NA,length(thesePos))
        for(n in 1:length(thisMapPos)){
          prevRows [n] <- which(thisChrMap[,2] < thesePos[n])[length(which(thisChrMap[,2] < thesePos[n]))]
        }
        thisMapPos <- thisChrMap[prevRows,3] + thisChrMap[prevRows,4]* (thesePos-thisChrMap[prevRows,2])
      }
      if(is.null(map) == TRUE){thisMapPos <- (as.numeric(thesePos)/physLengs[k]) * chrLengs[k]}
      chromMapPos <- c(chromMapPos,thisMapPos)
    }

  snpMat <- cbind(snpMat,chromMapPos)
  #########################################################################################
  # give genotypes to all of the individuals in the simulation. The
  # individual genotypes are determined by haplotype identity.
  #########################################################################################
  indIDs <- pedObject[,1]    # non-founder individuals you will genotype
  genoMat <- matrix(NA,ncol=length(indIDs)*2,nrow= nrow(snpMat))          # store the individual genotypes
  colIterator <- 1 # iterate through first allele columns
  het <- rep(NA,length(indIDs))
  print("genotyping locally-born individuals")
  for (i in 1:length(indIDs)){
    thisInd <- indIDs[i]
    chromeOneGeno <- NULL
    chromeTwoGeno <- NULL
    for (k in 1:chrNum){
      fstSegs <- fstJuncList[[k]][[i]] # Junction location on the first and second copies of the the kth chromosome in the ith individual
      secSegs <- secJuncList[[k]][[i]]
      fstOrigs <- fstChrOrigList[[k]][[i]]       # immigrant origins of the first and second chromosome haplotypes
      secOrigs <- secChrOrigList[[k]][[i]]
      thesePos  <- snpMat [which(snpMat[,1] == k),3]   # positions of the loci on this chromosome
      snpOrigVec1 <- rep(NA,length(thesePos))   # list storing the immigrant origin of each SNP on this chromsome
      snpOrigVec2 <- rep(NA,length(thesePos))   # list storing the immigrant origin of each SNP on this chromsome
      for(n in 1:length(fstOrigs)){
        theseBounds <- fstSegs[n:(n+1)]    # the bounds of this segment
        theseSNPs <-which(thesePos > theseBounds[1] & thesePos <= theseBounds[2]) # index the SNPs that resode in this segment
        snpOrigVec1 [theseSNPs] <- fstOrigs[n]
      }
      for(n in 1:length(secOrigs)){
        theseBounds <- secSegs[n:(n+1)]    # the bounds of this segment
        theseSNPs <-which(thesePos > theseBounds[1] & thesePos <= theseBounds[2]) # index the SNPs that resode in this segment
        snpOrigVec2 [theseSNPs] <- secOrigs[n]
      }
      thisFstGeno <- rep(NA,length(thesePos)) # vector of genotypes at these snps
      thisSecGeno <- rep(NA,length(thesePos))  # vector of genotypes at these snps
      fstGenoFounds <- unique(fstOrigs) # vectors of unique founder IDs represented in the individual's genotype
      secGenoFounds <- unique(secOrigs)
      for (j in 1:length(fstGenoFounds)){        # assign genotypes on the first chromosome copy
        thisFstGeno[which(snpOrigVec1 == fstGenoFounds[j])] <- immGenoMat[which(as.numeric(immGenoMat[,1]) == fstGenoFounds[j]),which(snpOrigVec1 == fstGenoFounds[j])+1]
      }
      for (j in 1:length(secGenoFounds)){        # assign genotypes on the first chromosome copy
        thisSecGeno[which(snpOrigVec2 == secGenoFounds[j])] <- immGenoMat[which(as.numeric(immGenoMat[,1]) == secGenoFounds[j]),which(snpOrigVec2 == secGenoFounds[j])+1]
      }
      # 'if' statements below deal with the rare occurence of a SNP being located very near a junction... Here R sometimes (rarely) makes a rounding error that makes the simulation leave a genotype missing
      if(sum(is.na(thisFstGeno)) > 0) {thisFstGeno[which(is.na(thisFstGeno) == TRUE)] <- thisSecGeno[which(is.na(thisFstGeno) == TRUE)]}
      if(sum(is.na(thisSecGeno)) > 0) {thisSecGeno[which(is.na(thisSecGeno) == TRUE)] <- thisFstGeno[which(is.na(thisSecGeno) == TRUE)]}
      if(length(thisFstGeno) != length(thisSecGeno)) {print(paste("error on chromsome",k,sep=  " "))}
      chromeOneGeno <- c(chromeOneGeno,thisFstGeno)
      chromeTwoGeno <- c(chromeTwoGeno,thisSecGeno)
    }
    het[i] <- sum(chromeOneGeno != chromeTwoGeno)/length(chromeOneGeno)
    genoMat[,colIterator] <- chromeOneGeno
    genoMat[,colIterator + 1] <- chromeTwoGeno
    colIterator <- colIterator + 2
  }
  genoMat <- cbind(snpMat,genoMat)
  colNams <- rep(NA,length(4:ncol(genoMat)))
  colNams[seq(1,length(colNams),2)] <- paste(pedObject[,1],"a",sep="")
  colNams[seq(2,length(colNams),2)] <- paste(pedObject[,1],"b",sep="")
  colnames(genoMat)[4:ncol(genoMat)] <- colNams

  ###########################################
  # build a time series of allele frequencies
  ###########################################
  allFreqMat <- matrix(NA,nrow=gens,ncol=simLociNum*chrNum)
  fstAllCols <- seq(4,ncol(genoMat),2)
  allFreqs <- NULL    # store the allele frequencies
  for(k in 1:gens){
    theseFstCols <- fstAllCols[which(pedObject[,4] == k)]
    theseAllCols <- sort(c(theseFstCols,theseFstCols + 1))
    allFreqMat[k,] <- rowSums(genoMat[,theseAllCols] == "A")/length(theseAllCols)
  }

  ################################################################
  # calculate pedigree inbreeding coefficients
  ################################################################
  kins <- kinship2::kinship(id=pedObject[,1],dadid=pedObject[,3],momid=pedObject[,2])
  pedF <- rep(0,nrow(pedObject))
  nonImms <- which(is.na(pedObject[,2]) == FALSE)
  for( k in 1:length(nonImms)){
    pedF [nonImms[k]]<- kins[which(pedObject[,1] == pedObject[nonImms[k],2]),which(pedObject[,1] == pedObject[nonImms[k],3])]
  }
  pedObject <- cbind(pedObject,pedF,het)

  ###############################################################################
  # save the chromosome segment origins for each individual on each chromosome
  ###############################################################################
  segLengs <- NULL   # calculate the maximim number of elements among vectors of junction locations
  for (i in 1:chrNum){
    thisChr1 <- fstJuncList[[i]]
    thisChr2 <- secJuncList[[i]]
    fstJuncNum <- rep(NA,length(thisChr1))
    secJuncNum <- rep(NA,length(thisChr2))
    for(j in 1:length(thisChr1)){
      fstJuncNum [j] <- length(thisChr1[[j]])
      secJuncNum [j] <- length(thisChr2[[j]])
    }
    segLengs <- c(segLengs,fstJuncNum,secJuncNum)
  }
  juncMat1  <- matrix(NA,nrow=nrow(pedObject)*chrNum,ncol=max(segLengs))
  juncMat2  <- matrix(NA,nrow=nrow(pedObject)*chrNum,ncol=max(segLengs))
  hapIDMat1 <- matrix(NA,nrow=nrow(pedObject)*chrNum,ncol=max(segLengs))
  hapIDMat2 <- matrix(NA,nrow=nrow(pedObject)*chrNum,ncol=max(segLengs))
  rowIter <- 1 # iterate destination rows
  for(i in 1:length(indIDs)){
    for(j in 1:chrNum){
      juncMat1[rowIter,1:length(fstJuncList[[j]][[i]])] <- fstJuncList[[j]][[i]]
      juncMat2[rowIter,1:length(secJuncList[[j]][[i]])] <- secJuncList[[j]][[i]]
      hapIDMat1[rowIter,1:length(fstChrOrigList[[j]][[i]])] <- fstChrOrigList[[j]][[i]]
      hapIDMat2[rowIter,1:length(secChrOrigList[[j]][[i]])] <- secChrOrigList[[j]][[i]]
      rowIter <- rowIter + 1
    }
  }
  pedObject  <<- pedObject
  juncMat1   <<- juncMat1
  juncMat2   <<- juncMat2
  hapIDMat1  <<- hapIDMat1
  hapIDMat2  <<- hapIDMat2
  genoMat    <<- genoMat
  allFreqMat <<- allFreqMat
  print("********** pedigree simulation done**********")
}
