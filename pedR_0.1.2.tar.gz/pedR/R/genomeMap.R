#' An example linkage map
#'
#'    genomeMap returns a dataset containing genetic (centiMorgans) and physical positions of nucleotide sites in a
#'    hypothetical genome. Note that in the case of custom map files, the first position entry for each chromosome
#'    must have genetic and physical positions equal to 0. Variables are defined below.
#'
#' \itemize{
#'   \item chrom. Chromosome assignment of the locus
#'   \item genPos. Genetic position of the locus (in centiMorgans)
#'   \item physPos. Physical position of each locus (in megabases)
#' }
#'
#' @docType data
#' @keywords datasets
#' @name genomeMap
#' @usage data(genomeMap)
#' @format A data frame with 500 rows and 3 variables
#'
#' @author Marty Kardos (martykardos@@gmail.com)
NULL
